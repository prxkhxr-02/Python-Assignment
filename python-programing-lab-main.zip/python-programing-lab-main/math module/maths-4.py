##This method returns a floating-point number after raising e to the given number.
import math    
number = 5e-2  # small value of of x    
print('The given number (x) is :', number)    
print('e^x (using exp() function) is :', math.exp(number)-1)