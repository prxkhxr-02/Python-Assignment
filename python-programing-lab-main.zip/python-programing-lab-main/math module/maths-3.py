##This method returns base 10 logarithm of the given number and called the standard logarithm.

import math    
x=13  # small value of of x    
print('log10(x) is :', math.log10(x))   