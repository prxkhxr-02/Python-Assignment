##This method returns the natural logarithm of a given number. It is calculated to the base e.


import math    
number = 2e-7  # small value of of x    
print('log(fabs(x), base) is :', math.log(math.fabs(number), 10))    