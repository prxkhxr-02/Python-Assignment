##This method returns the power of the x corresponding to the value of y.
import math  
number = math.pow(10,2)  
print("The power of number:",number)