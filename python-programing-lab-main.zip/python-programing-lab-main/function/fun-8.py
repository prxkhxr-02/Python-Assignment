#Generate a Python list of all the even numbers between 4 to 30

print(list(range(4, 30, 2)))