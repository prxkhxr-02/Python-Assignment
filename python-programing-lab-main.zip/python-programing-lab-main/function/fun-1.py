##Create a function in Python

def demo(name, age):
    # print value
    print(name, age)

# call function
demo("Ben", 25)