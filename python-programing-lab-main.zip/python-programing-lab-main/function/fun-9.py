#Find the largest item from a given list

x = [4, 6, 8, 24, 12, 2]
print(max(x))