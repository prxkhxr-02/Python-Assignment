import numpy as np
list_of_numbers = [x for x in range(0, 101, 2)]

o = np.array(list_of_numbers)

print(o)