import numpy as np
a = np.array([[2.5, 3.8, 1.5],
              [4.7, 2.9, 1.56]])

o = a.astype('int')

print(o)