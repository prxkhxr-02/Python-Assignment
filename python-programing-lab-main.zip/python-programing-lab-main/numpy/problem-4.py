import numpy as np
a = np.array([x for x in range(27)])

o = a.reshape((3,3,3))

print(o)