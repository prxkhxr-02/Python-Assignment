import numpy as np
a = np.array([[1, 0, 0],
              [1, 1, 1],
              [0, 0, 0]])

o = a.astype('bool')

print(o)
 