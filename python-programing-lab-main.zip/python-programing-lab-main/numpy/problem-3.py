import numpy as np
i = np.eye(4)

print(i)